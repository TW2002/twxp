:banner
	setVar $SWITCHBOARD~message $script_title&" starting up!*"
	gosub :SWITCHBOARD~switchboard
return
