:wait_for_command
halt
