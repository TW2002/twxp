:addFigToData
	setSectorParameter $target "FIGSEC" TRUE
return
