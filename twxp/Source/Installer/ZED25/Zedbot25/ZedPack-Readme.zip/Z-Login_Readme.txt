Title: Z-Login
Version: 1.33
Author: Zed
Contact: Archy at http://archysportal.com
Credits: Caretaker - TerraKit.

Zed's Login Script
-------------------

Logs you into the game automatically and optionally runs a specified script (such as your bot).
If you are logging in after being killed it will land you on Terra and start TerraKit if the script is available in your scripts folder.
If you are logging in to a new game it will create or join your corp, and also set your subspace channel along with your cn2 and cnc settings (both off). It will also set your warpdrive setting to always on.

The first time you use the script it will offer a menu where you can specify settings such as alias, ship name, planet name, corp name and password, and subspace channel.
After you fill in these details and press G to go it will save the information and disconnect. You should reconnect and the script will log you in.

The settings are saved in a file called z-globals.cfg located in your TWX root. 
Login will ADD entries to the z-globals.cfg file for loading specific scripts at login. (_ck_equip_haggle_tracker, Z-Figmon, and Z-bot).
You can edit this file to change settings using notepad (or delete it to have the menu reappear next time you login).
You can override the Z-Globals.cfg file for any particular game by copying it and renaming it to GAMENAME_Z-Globals.cfg where GAMENAME is the name of the TWX database for that particular game. Z-Login will read its settings from that file just for that game.

If you do not use an alias you should not fill in that option. All other options should be filled in.

NOTE: Although the script will allow you to specify more than one script to load after login, it is not recommended to load too many as they may conflict during the load process. (Test to see if your setup will handle it.)
Also NOTE that any scripts loaded should be able to load from the Citadel prompt if you log off at a planet.
Logging in to a new game with a starting planet doesn't count, Z-Login will jump off the planet to load scripts in this case.

It can safely load _ck_equip_haggle_tracker, Z-Figmon, and Z-bot (and will by default).

Z-Login keeps logs of various events in a file called GAMENAME_Z-Logs.log in the TWX Root.

Z-Login can be used with Z_OnTime to login to a game at a specified time when you are away from keys.
Z-Login is recommended for use with Project-Z.

INSTALLATION
-------------
Place the script in your scripts folder.

