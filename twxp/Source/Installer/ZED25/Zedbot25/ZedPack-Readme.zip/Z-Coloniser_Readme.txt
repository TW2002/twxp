Title: Z-Coloniser
Version: 1.14
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Coloniser
----------------------
A Red/Blue T-Warp/B-Warp Coloniser.

You can set the fuel source to be a port or any planet in sector.
In B-Warp mode the B-Warp planet can be any planet in sector.
You can set the script to refurb fighters from Terra, the fuel planet, or the planet being colonised.
You can set how many trips to run and the script will stop when done.

Red players need to set the jump point to a figged sector close to sector 1.
Blue players have the option of a Turbo mode (about 25% faster but no progress window or safety checks).

This Script is bottable (for blues only). Type   Z-Coloniser help   for bot info.

INSTALLATION
-------------
Place the readme, and the .wav file in your TWX root folder.
Place the script in your scripts folder.
