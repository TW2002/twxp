Zed's Script Pack - by Archibald H. Vilanos III (aka Zed)
---------------------------------------------------------
Contents:
---------
* Z-Armourer     - Class 0 Buydown (buys fighters and shields for your planet from Rylos or Alpha)
* Z-Backdoor     - Backdoor finder (does a mini ztm to find backdoors for Stardock, Terra, Rylos, Alpha and more)
* Z-Bot          - Player Frontend and Bot. (over 70 Internal commands, add more via the Z-Options file)
* Z-Call         - Call Saveme (used with Z-Rescue)
* Z-Coloniser    - Red/Blue Coloniser (Botable for blues)
* Z-Decash       - Collect credits from corpies as they cash (no stopping necessary)
* Z-Fetch        - Jumps to Stardock and buys consumables according to a shopping list (botable)
* Z-Figmon       - Fighter grid monitor (among other things)
* Z-ListGridder  - Mows to each sector in a list and figs it (optionally mines and limps as well)
* Z-Login        - Completely automated login script.
* Z-OnTime       - For logging into a game when you are away from keys (needs Z-Login)
* Z-OreUp        - Buys down fuel for a planet from the port in sector (fast)
* Z-Pdriver      - Automates many tasks with a planet. Operates from a list of sectors. (good for bubbles)
* Z-Rescue       - Saveme Script. (Used with Z-Call, and Z-Bot)
* Z-SafetyNet    - Xports you into a safe ship when an enemy attacks or comes into sector while cashing.
* Z-SectorLister - Creates lists of sectors based on a variety of optional criteria. (Sorts for fuel efficiency)
* Z-SPTool       - Sector Parameter Management Tool.
* Z-TransCash    - Automates the transfer of cash to/from other players via the galactic bank.
* Z-Unload       - Unloads all scripts (system scripts included) except those in the ignore list. (put it on a hot key)
* Z-Scout        - Simple scout runs around the universe dropping a fig in each sector.
* ClearTWX       - A batch file for clearing the game files in the TWX Root after a game has finished.
----

Each script Zip contains a readme file with more information. Many of the scripts have built in help and/or menus.

About Z-Bot.
------------

Z-Bot was written by myself from the ground up (it started as a blank notepad screen).
Many ideas have come from using Mombot and Kraakenbot along with a few of my own.

Here is a list of Z-Bot features:

* Over 80 internal bot commands - All with built-in help screens.
* Extensible. All Internal commands can be replaced with external commands using the Z-Options.cfg file.
* Extra bot commands can be added using the Z-Options.cfg file.
* Full Featured Charger, Mower and Twarper (with attack, capture, surround, and port). Move around the universe fast and easy.
* User definable Menu System available with a double tap of the comma key (for standalone scripts).
* Defineable hotkeys. All internal key assignments can be customised.
* Auto Sub-Space changer changes channels every hour.. and stays in sync with your corpies.
* Bot commands can be sent via Subspace or Personal Message (internal commands will respond in kind).
* Built in Pdrop, Citkill, Citevac, planet invasion routines and much more.
* Designed to work with existing Zed Scripts such as Z-FigMon and Z-Login.
* Sector Avoids management built in.
* Central Menu for changing options available using the TAB key.
* Attack and Capture macros can be edited in the Z-Options.cfg file.
* Self Destruct prevention built in.
* Creeper Mode.
* Sentry Mode.
* Log file maintained for each game.
* The OreUp and Call scripts are built in (stand alone versions are also in the pack).
* much more...

INSTALLATION
-------------
The Zed-Pack.exe is a self extracting zip file. Unzip it to your twx root and allow it to maintain its relative folder structure. It will place files in the TWX Root folder, the TWX scripts folder and in a folder in the TWX scripts folder called Readme.

NOTE
-----
I have decided to release this script pack to the public. (available for download NOW at http://tradewarsportal.com)
I hope you find some of these scripts useful.
I will be supporting this script pack from my website at http://tradewarsportal.com.

Credits to VidKid and Parrothead who have helped me along the way. Thanks fellas.
Special thanks to Traveler for his patience in helping me test the scripts.

Regards Archy.

