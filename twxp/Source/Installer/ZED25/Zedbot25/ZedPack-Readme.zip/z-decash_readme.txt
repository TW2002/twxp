Title: Z-Decash
Version: 1.02
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Decasher
--------------

Takes credits on-the-fly automatically from a corpy while he is cashing.
This command can be stand-alone or botted. Help is available over SS
with the command  '<botname> z-decash ?

Usage: z-decash [amount] [floor] [pauses]

      amount: amount of cash to attempt to take each time.
              Default: 300,000,000.
              Note that this will try 30,000,000 and then 3,000,000
              until it gets down to trying to take 3 credits.
       floor: Decasher will go into pause mode when the corpy
              reaches this minimum amount of cash.
              Default: 1,000,000
      pauses: Number of times to not decash the corpy during
              pause mode.
              Default: 10

Extra Commands available in Menu mode:
      Double: On or Off. When ON this will cause the script to attempt
              to take cash when your corpy is warping into the sector
              or when Twarping in. This is in addition to the normal
              mode of decashing when blasting or lifting off from a 
              port or planet.
              Default: OFF
      Sound : On or Off. Turns on the ding when cash is grabbed.
              Default: OFF


      