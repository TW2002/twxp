Title: Z-Unload
Version: 1.01
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Script Unloader
----------------------
Unloads ALL Scripts that are running including system scripts.
You can setup an ignore list of scripts that you do not want unloaded if necessary.


Creating an ignore list
------------------------
Create a text file in your TWX Root and name it Z-Unload.cfg.
Place the names of the scripts to ignore in this file (1 per line).
Include the file extension in the name.


Example Z-Unload.cfg
---------------------

Z-Authorise.cts
myscript.ts
AnotherScript.cts


INSTALLATION
-------------
Place the readme, and the .wav file in your TWX root folder.
Place the script in your scripts folder.
