Title: Z-Call
Version: 1.05
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Call Saveme
------------------
A Call Saveme script.

Sends a Call for saveme over subspace, when the planet arrives you will jump on and refurb fighters, landing in the Citadel.

Start this script from the Command Prompt.

INSTALLATION
-------------
Place the script in your scripts folder.
