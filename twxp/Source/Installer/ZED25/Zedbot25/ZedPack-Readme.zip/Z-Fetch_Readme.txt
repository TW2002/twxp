Title: Z-Fetch
Version: 1.16
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Fetch
------------
Twarps you to Stardock and buys specified consumable items and twarps back quickly and (hopefully) safely.
All items bought are maxed so make sure you have enough cash. (no check for cash is performed)
If you are 1000 alignment or higher (blue) it will Twarp straight in and dock.
If you are not at least 1000 alignment it will twarp to an adjacent or a backdoor and then move straight in and dock.
It cleans limpets if necessary.

You will need enough fuel ore on board for the return trip, also a twarp drive, and enough turns left in a turn game for the trip. All this is checked before you leave.

Z-Fetch will make use of a B-Warp if it is available.

Z-Fetch is bottable. Use the command   zfetch help   to get help.

Start this script from the Command or Citadel Prompt.

INSTALLATION
-------------
Place the script in your scripts folder.
Place the .wav files in your TWX Root.
