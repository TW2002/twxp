Title: Z-SPTool
Version: 1.08
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Sector Parameter Tool
----------------------------
Allows you to view/modify/add/delete the game's database sector parameters.
Allows you to determine which parameters are shown in the menu as standard (whether they exist or not in the database) allowing you to easily set any unset parameters.
You can set or clear parameters across all sectors at once.
You can set or clear parameters across all sectors in a list. (Use Z-SectorLister to create the list)
You can also count sectors based on the value of a parameter and optionally create a sector file of all the sectors counted.

Upon running this script for the first time it will create a file in your TWX Root named z-sptool.cfg.
You can edit this file to add or remove the standard parameter options from the menu (those shown in the top section of the menu).
There are notes in this file explaining the meanings of the entries. 
You can delete the z-sptool.cfg file to have it automatically re-created with default settings.

Note: Use this script with care as it allows you to change information stored in the TWX database for each game.

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the script in your scripts folder.
