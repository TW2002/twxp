Title: Z-SectorLister
Version: 1.23
Author: Zed
Contact: Archy at http://archysportal.com
Credits: Thanks to Parrothead for help with the sort algorithm.

Zed's Sector List Generator
---------------------------
Generates a list of sectors either from the entire universe or from a nominated file.
The sectors can be filtered based on criteria such as figged/unfigged, mined/unmined, limped/unlimped, busted/not busted, planets/no planets, beacon/no beacon, intersections, warps in, figged warps in/unfigged warps in, fedspace/not fedspace, explored/unexplored sectors, Sectors within a certain range, port exists/does not exist, buy/sell certain commodities, minimum and maximum available commodities (buy or sell), avoided/unavoided.
All filters can be ignored and any combination can be set as an include or exclude.
Explored means visited, seen by a long range scan, or in a ZTM.
The list can optionally be sorted by distance from your current sector.
The script starts with default settings that will simply output the entire universe.

You can use an exclude list file to exclude all sectors in the exclude list from the output list.

Please note that the sort procedure can take a while if there are a lot of sectors in the filtered list. Use the BACKSPACE key to abort a long sort.

Also note that the sort option requires the paths between sectors to be known either through a ZTM or actually travelling between them for best results.

Using the Figged sectors, Mined sectors, or the Limped sectors filters requires a sector parameter update for the FIGSEC, MINESEC and LIMPSEC parameters respectively.
You can use the Z-Figs, Z-Mines, and Z-Limps scripts to take care of this requirement.

You can set Z-SectorLister to keep the previous output file allowing for several different lists to be combined. Duplicate sectors in the list are discarded.

The minimum/maximum port commodities are reset to N/A with a value of 0.
Anything marked N/A is ignored as a filter (not used).

The source, output, and exclude filenames offered by default can be edited in a file called z-sectorlist.cfg located in the TWX Root.

Start the script from the COMMAND prompt.

INSTALLATION
-------------
Place the readme, and the .wav file in your TWX root folder.
Place the script in your scripts folder.

Source and output files will be looked for/placed in the TWX root.
