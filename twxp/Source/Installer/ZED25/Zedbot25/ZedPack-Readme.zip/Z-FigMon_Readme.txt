Title: Z-FigMon & Z-Figs & Z-Mines & Z-Limps
Version: 1.38 & 1.06 & 1.05 & 1.05
Author: Zed
Credits: Parrothead, Caretaker.
Contact: Archy at http://archysportal.com

Zed's Fighter Monitor and & Filer
----------------------------------

Z-FigMon 1.38
--------------
Monitors your fighter grid and updates the FIGSEC parameter in the TWX Database when fighters are destroyed or new ones are put down.
Clears the BUSTED SectorParameter when a corpy busts in a sector that you have previously busted at.
Listens for corpys laying figs and updates those sectors as they are figged. (works with Z-Grid)
Built in Proximity Alert will warn you when a fig gets hit within 3 sectors of your ship, your base and/or when a fig gets hit in a sector on a list in a file called GAMENAME_proximity.txt. Existence of this file sets Z-FigMon to use it.
If the variable $z_base exists in the database CFG then warnings for sectors within 3 sectors of the $z-base sector will also given. $z_base can be set using figmon (see below) or in several ZeD scripts such as Z-Menu, Z-Charger, and ZRR.
Warnings can be accompanied by the sound of your choice. copy and rename a wav file to proximity.wav and place it in your TWX Root folder.See below for how to turn sound on. The sound will not play more frequently than about once every 60 seconds.

You should add this to the list of automatically run scripts in Z_Login.
Z-FigMon runs as a system script.

You can send the text  yourbotname FIGMON RESET  via subspace to make Z-FigMon read the Base Sector, proximity.txt, and check for proximity.wav to enable warning sounds.
Send the text  yourbotname figmon CLEARALLBUSTS  via subspace to unconditionally clear the BUSTED sector parameter in all sectors.
Send the text  yourbotname figmon CHECKBUSTS  via subspace to clear the BUSTED sector parameter in all sectors if it is a bust clearing day.
Send the text  yourbotname figmon BROADCAST ON  to set broadcasting of proximity alerts over subspace ON.
Send the text  yourbotname figmon BROADCAST OFF  to set broadcasting of proximity alerts over subspace OFF.
Send the text  yourbotname figmon SOUND ON  to turn the proximity sound alert ON.
Send the text  yourbotname figmon SOUND OFF  to turn the proximity sound alert OFF.
Send the text  yourbotname figmon BASE to set the base sector.
Send the text  yourbotname figmon AUTOSS ON to turn autosubspace rotating ON.
Send the text  yourbotname figmon AUTOSS OFF to turn autosubspace rotating OFF.
Send the text  yourbotname figmon ALL ON to turn sound, broadcasting and autoss ON.
Send the text  yourbotname figmon ALL OFF to turn sound, broadcasting and autoss OFF.
Send the text  yourbotname figmon QSS to send QSS information over SubSpace.
Send the text  yourbotname figmon SCRIPTS to send a list of active scripts over SubSpace.
Send the text  yourbotname figmon BOT ON to load the Z-Bot.
Send the text  yourbotname figmon HELP or ? to display the above commands.

Note that some features require Z-Login 1.15 or higher.
Busts will usually be cleared automatically at Extern.
Z-Figmon keeps logs of various events in a file called GAMENAME_Z-Logs.txt in the TWX Root.
Z-Figmon keeps a list of sectors where your grid has been hit in a file called GAMENAME_GRIDHITS.TXT.

Z-Figs 1.06
-----------
Refreshes your FIGSEC parameter for every sector in your TWX database.
Reports how many sectors are figged and what the difference is since the last time you refreshed.
Results are output to Sub-space.

Z-Mines 1.05
------------
Same as Z-Figs but for Armid Mines.

Z-Limps 1.05
------------
Same as Z-Figs but for Limpet Mines.
