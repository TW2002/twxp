Title: Z-Scout
Version: 1.05
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Universal Scout
---------------------
Moves around the universe dropping figs and scanning as it goes.
Favours unfigged sectors. Will not enter sectors with planets or traders in them.
By default it drops 1 fig in each sector as corporate defensive. Will adhere to the options set in Z-Bot's options if present.
No Menu.. No Parameters.. 

Run this script from the COMMAND prompt.

Can be botted.

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the script in your scripts folder.
