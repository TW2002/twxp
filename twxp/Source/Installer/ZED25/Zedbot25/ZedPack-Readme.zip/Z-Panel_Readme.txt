Title: Z-Panel
Version: 1.03
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Info Panel
-----------------
Displays a window panel of assorted information which is updated live.
You must run Z-Bot to use this script.
Z-Bot has a hotkey assigned to toggle the panel on and off. (Default SHIFT-I)

INSTALLATION
-------------
Place the script in your scripts folder.
