Title: Z-ListGridder
Version: 1.18
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Sector List Gridder
-------------------------
Grids a list of sectors placing fighters and optionally mines and limpets.
Good for gridding bubbles, but not particularly safe.
You can also pickup figs by setting the figs to lay to 0. Make sure you have room on the ship to carry the extra figs. Note that this will pick up figs on the way between the listed sectors as well.
If you are placing mines and/or limpets it will refurb them at Stardock. You will need a Twarp drive and plenty of cash for this.
You can optionally surround each sector in the list. (good for 5 and 6 ways).
You can also optionally scan each sector (this does NOT make the script any safer).
You can set the script to return to the start sector when done.

Z-ListGridder uses the file GAMENAME_sectorlist.txt by default (the default output filename of Z-SectorList). You can change this at the menu along with how many fighters, mines and limps to drop, Corporate or Personal, Toll, offensive or defensive stance settings.
The script will mow to each sector in the list, dropping figs mines and limps as it goes.
It will refurb at stardock using the Twarp and will find fuel as it needs it.

The sector list filenames offered by default can be edited in a file called z-sectorlist.cfg located in the TWX Root. Z-ListGridder uses the OUTPUT filenames in this list.


Start this script from the Command Prompt.

INSTALLATION
-------------
Place the script in your scripts folder.
Place the .wav files in your TWX Root.
