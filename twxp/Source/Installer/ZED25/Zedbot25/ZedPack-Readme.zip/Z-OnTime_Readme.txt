Title: Z-OnTime
Version: 1.08
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Login On Time
--------------------
Allows you to enter a game at a specified time unattended. Works in conjunction with Z-Login.

You can set a date and time for the login to proceed. It will sit disconnected until the specified time and then connect, handing control over to Z-Login.
You can optionally set Z-Ontime to set Z-FigMon's Auto Subspace changer to ON.
You can optionally set Z-Ontime to charge you to Stardock if Stardock is shown on the V-screen.
You can optionally specify a script to be run when Z-Login is complete (aside from those specified in Z-Login that run at every login). This could be a ZTM script for example.

You should create a new TWX database for the game before running Z-OnTime.

ADJUSTING THE START DATE AND TIME:
----------------------------------

The date is shown in the format DD/MM/YYYY - HH:MM

To increment the days, months years and hours use the following keys:
d - Days
m - Months
y - Years
H - Hours
n - Minutes.

To decrement the days, months years and hours use the same keys SHIFTED.
D - Days
M - Months
Y - Years
H - Hours
N - Minutes.

As you adjust the date and time the day of the week will be displayed.

Z-OnTime makes an entry in Z-Logs.log in the TWX Root folder when it connects successfully.

Run this script from OUTSIDE the game (while DISCONNECTED).

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the script in your scripts folder.

NOTE: It helps to set AUTO RECONNECT in TWX to ON.
