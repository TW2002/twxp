Title: Z-Bot
Version: 2.10
Author: Zed
Contact: Archy at http://tradewarsportal.com
Credits: Traveler, CareTaker, Remco Mulder (Mass Upgrade), Lonestar (Wsst), Cherokee (buydown, Nego)

Zed's Z-Bot
----------------
A user frontend and bot.

Features
---------
1. THE most advanced and extensive HELP SYSTEM available in a bot.
   
   * Help screens for EVERY internal command.
   * Search facility for both internal and external commands.
     - Searches through commands, descriptions, filenames, and internal keywords.
     - Mombot users see a search result list when a mombot style help command is used.
   * First letter index lists.
   * Category views.
   * Descriptive command lists, concise tables of commands.
   * Extra help screens for the Movement system, Z-Bot configuration, and help on help!
   * User supplied descriptions for external scripts.
   * Automatic (or user initiated) sorting of all lists (fast).

2. Advanced, fully featured MOVEMENT SYSTEM.
   
   * Commands for MOW, CHARGE, TWARP, FS (get me to fedspace).
   * Hotkeys for MOW, CHARGE, TWARP, BLINDWARP. (all lead to a common interface).
   * Arrival options for both commands and hotkeys include:
     port, land, surround, kill, cap, gas, call saveme, wavecap, buzz, run a macro,
     run ANY bottable command with parameters.
   * Shortcuts for STARDOCK, RYLOS, ALPHA, BASE, SAFE SECTOR, LAST HIT SECTOR, LAST SECTOR.
   * Automatic gasing, bwarping, safety checks, scrubbing at class 0s and STARDOCK.
   * Integrated JUMPLIST system for moving through a list of sectors sequentially.
   * A special mac command called ZMAC with the ability to use the movement system.

3. COMPLETE script management with OVER 160 BUILT-IN COMMANDS.

   * ALL of your scripts, bottable or standalone, can be made a part of Z-Bot.
   * ANY internal z-bot command can be replaced (overridden) with an external script.
   * Virtually unlimited capacity to add more commands, all with searchable descriptions.

4. UNIQUE features.

   * BS command is a bottable BUY and OUTFIT a SHIP command.
   * The AUTOMATE system allows you to automate tasks on the fly when you don't have a script.
   * The FILE TRANSFER SYSTEM allows the transfer of authorised data and lists between corpys.
   * The SWITCHBOT command allows your corpys to switch you to another bot.
   * Self-Bot COMMAND HISTORY (easily re-run any of your last 9 commands)
   * AutoSS Subspace channel changing system.
   * The Macro Command Looper allows you to run macros and commands repeatedly.
   
5. CONFIGURE and PERSONALISE your bot to the EXTREME.
	
   * The CONFIGURATOR allows you to edit Menus and Configuration files.
   * Personalise TURN HERALD phrases and smilies.
   * Personalise Corporate Mottos displayed on Asset reports and when the Z-Bot starts.
   * Personalise Banners that can be sent over Fedcom or SS.
   * Completely configurable FedCom Responder (FCR).
   * Completely configurable, multi-level, unlimited menu-system for standalone scripts.
   * Completely configurable HOTKEY system. (including create your own)
   * Settings and options to change everything. (or just leave the defaults)

6. SPEED with uncompromising STABILITY.

   * INTERNAL commands are already loaded. No waiting at runtime.
   * SUPPORT scripts keep your Z-Bot alert and ready for action no matter what!

7. Other MAJOR Features.

   * SPG - Smart Passive Gridder
   * AUTOREFURB automated red-casher refurbing system.
   * Complete SHIP/CIT CAPPING/KILLING system.
   * Built in SECTOR WALKER and CITADEL SIEGE menus.
   * Toggle-able "Update in Real-Time" Information panels

8. IT'S STILL BEING DEVELOPED!

   * The Z-Bot is continually being expanded and improved.


Default Keys
-------------

[>]      - Self Bot key.
[,]      - Double Tap the comma key to bring up the user definable menu system.
[[]      - The Mow key.
[]]      - The Charge key.
[}]      - The TWarp Key.
[{]      - Blindwarp key.
[TAB]    - Options Menu key.
[CTRL-Z] - Bot ON/OFF key.
[J]      - Hook & Tow key.
[T]      - TopOff key. (Fill up with fighters from the sector)
[X]      - Xfer key. (Transfer figs, mines, and shields between corpies)
[.]      - Fast Xfer key.
[B]      - Display a banner.
[-]      - Citadel "siege" and Walker menus.
[D]      - Disrupt mines in adjacents key.
[S]      - SafetyNet key.
[G]      - Game Info Key.
[K]      - Hotkey Menu.
[E]      - eProber - eProbes a list with available eProbes and refurbs if at StarDock with cash.
[O]      - Short ZTM (map a route to and from each sector in a list)
[C]      - Ship Cap Key.
[A]      - Attack - Throws a wave of fighters at anybody in sector.
[F]      - Finds fuel - Will buy fuel when it finds it.
[P]      - Sets the current planet to the MAIN planet.
[V]      - View Matrix - Same as the MATRIX bot command.
[W]      - Hook & Tow a manned ship. Same as HOOK bot command.
[L]      - Stop all non-system scripts.
[U]      - Automate Menu.
[H]      - User defined hot key list
[I]      - Info Panel
[Z]      - Colonist Watch Panel
[(]      - Self Bot History

The above key assignments can be edited in the Z-Options.cfg file in the TWX Root.

If the CTRL Key assignment you want to use is being hijacked by Swath, you can over-ride it.
You need to create a Macro in swath (hammer button) that sends the appropriate code to TWX.
You then need to create a "Key Pressed" trigger in Swath (bell button) that runs the macro.
The macros needed are listed here:

CTRL-A  ^(1)
CTRL-B  ^(2)
CTRL-C  ^(3)
CTRL-D  ^(4)
CTRL-E  ^(5)
CTRL-F  ^(6)
CTRL-G  ^(7)
CTRL-H  ^(8)  (same as backspace key)
CTRL-I  ^(9)  (same as tab key)
CTRL-J  ^(A)
CTRL-K  ^(B)
CTRL-L  ^(C)
CTRL-M  ^(D)  (same as enter key)
CTRL-N  ^(E)
CTRL-O  ^(F)
CTRL-P  ^(10)
CTRL-Q  ^(11)
CTRL-R  ^(12)
CTRL-S  ^(13)
CTRL-T  ^(14)
CTRL-U  ^(15)
CTRL-V  ^(16)
CTRL-W  ^(17)
CTRL-X  ^(18)
CTRL-Y  ^(19)
CTRL-Z  ^(1A)

UPARROW     ^(1B)^(4F)^(41)
DOWNARROW   ^(1B)^(4F)^(42)
RIGHTARROW  ^(1B)^(4F)^(43)
LEFTARROW   ^(1B)^(4F)^(44)

Use the bot command   help  to get help on commands. Type  >help  and press ENTER.

If you have set a bot password in the TAB options menu, use the form below for PM botting.

BOTNAME BOTPASSWORD COMMAND PARAMETER_1 PARAMETER_2 etc...

Extra Files
------------
Several Files will be created in your TWX Root.
The Z-Options.cfg file is where you add more scripts to the bot.
The zp-*.mnu files are the User Defined Menu (you can edit/delete or add to the menu using these files).

Some of these files contain working examples for you to edit and experiment with.


The Standalone Script Menu Files
----------------------------------

The format for the menu files (zp-*.mnu) is as follows.

* The first line is the Menu Title to be displayed at the top of the menu.

Each line after that is 1 line per menu option divided up into 4 sections as follows.

* The first section is the Option type, 
  Either an S (for script), D (for Daemon) or an M (for Menu).
  A Daemon is a script that runs in the background. Z-Bot returns to GENERAL mode after loading a script type "D".

* The second section is the 2-digit code to activate the option. Any 2 digits (0-9 A-Z) will do. 
  These should be unique for each menu page.

* The third section is the filename of the script or menu file to load.
  (NO SPACES IN THE FILENAME PLEASE)

* The fourth section is the title of the option to appear in the menu.

Note that the Top level menu is named  zp-main.mnu - this is hard coded but ALL other menus and their filenames are optional.

The Options Menu
-----------------
ALL PAGES
----------
-=[<] PAGE x [>]=-              - Page Selection
-=[,] PAGE x [.]=-              - Page Selection

-=[ENTER]=- Continue            - Leave options menu, return to the bot
-=[Q]=- Quit                    - Terminate the bot script.

Page 1
-------
-=[1]=- Base Sector : [0]       - Your main base sector (for mow, charge and twarp destinations).
-=[2]=- Safe Sector : [0]       - Your main safe sector (for mow, charge and twarp destinations).
-=[3]=- Safe Ship   : [0]       - Your safe ship.
-=[4]=- Main Planet : [0]       - Your main planet. If available, used as a planet to land on when none is specified.
-=[5]=- Dock Safer  : OFF       - Check STARDOCK before trying to move/port there.
-=[6]=- Call Mode   : Normal    - Set to FAST to call the saveme before you leave for the target sector. 
-=[7]=- Xport Update: NO        - Update ship info after xporting to another ship.
-=[8]=- Auto IG ON  : OFF       - Turn IG on when you xport to another ship.
-=[9]=- Sound       : ON        - Turns ON/OFF the use of sound in Z-Bot.

Page 2
-------
-=[1]=- Drop Figs   : 1         - Number of figs to drop when mowing or surrounding or gridding
-=[2]=- Drop Mines  : 0         - Number of mines to drop when mowing or surrounding or gridding
-=[3]=- Drop Limpets: 0         - Number of limps to drop when mowing or surrounding or gridding
-=[4]=- Drop Owner  : Corporate - Owner for dropped figs (Corporate or Personal)
-=[5]=- Fighter Type: Defensive - Type of dropped figs (Offensive, Defensive or Toll)
-=[6]=- Min Figs    : 20        - Minimum fighters to keep when gridding.
-=[7]=- Min Turns   : 20        - Minimum turns to keep when using them automatically.
-=[8]=- Furb Ship   : Not Set   - Buy Ship Letter (at dock) for the Furb Ship.
-=[9]=- Furb Holds  : 0         - Extra holds to buy for the Furb Ship.
-=[A]=- Wave Volley : None      - Number of waves to throw during a SafetyNet emergency.
-=[B]=- PDrop Delay : 10        - Sets the delay before returning to base after a pdrop.
-=[C]=- Team Name   : None      - Sets a team name for the bot to respond to commands aimed at more than 1 bot.
-=[D]=- In-Game Name: Not Set   - Sets your ingame name (ALIAS or LOGINNAME) for the bot to filter your name from player selection in the bot and various scripts.

Page 3
-------
-=[1]=- MSL Echos   : OFF       - Places an [MSL] tag on the command line when you are in an MSL
-=[2]=- Bust Echos  : OFF       - Places a [BUST] tag on the command line when you have busted in sector
-=[3]=- LastRS Echo : OFF       - Places a [LASTRS] tag on the command line when you in the sector you last robbed.
-=[4]=- Port Echos  : OFF       - Places a tag on the command line when you are in a CLASS 0 sector, STARDOCK, BASE, SAFE, or TERRA.
-=[5]=- Limp Alarm  : OFF       - Toggles the alarm for when a limpet is picked up.
-=[6]=- OnlineWatch : OFF       - Toggles ON/OFF Online Watch.
-=[7]=- CLV Watch   : OFF       - Toggles ON/OFF the extra CLV info with Online Watch.
-=[8]=- HeraldTurns : OFF       - Toggles ON/OFF Herald Turns over SS when player gets turns each hour. Edit The Z-Heralds.cfg and the z-smilies.cfg to customise.
-=[9]=- Prox. Alert : OFF       - Toggles ON/OFF the figmon PROXIMITY alert.
-=[A]=- Alert on SS : OFF       - Toggles ON/OFF Broadcasting Proximity alerts over SS.
-=[B]=- Time Check  : ON        - Turns off the Time Check that occurs every 30 minutes.
-=[C]=- Bot Shutdown: ON        - Turns off the Bot's Server Shutdown triggers.
-=[D]=- Silent Mode : OFF       - Suppresses SS output from the bot.
-=[E]=- Fig Herald  : OFF       - Heralds over SS when you lay a fig with the gridders. Allows corpies to receive fig info in realtime with FigMon.

Page 4
-------
-=[1]=- Delete Avoids File      - Deletes the avoids backup file.
-=[2]=- Export Avoids List      - Exports the internal avoids to the backup file.
-=[3]=- Import Avoids List      - Imports the external avoids from the backup file (offers to clear internals).
-=[4]=- RemoteAccess: ON        - Toggle REMOTE ACCESS availability.
-=[5]=- AutoSS      : ON        - Turns ON/OFF the auto subspace channel changer
-=[6]=- AutoSS Seed : 0         - If used, all corpys must have the same seed. Extra layer of security for AutoSS.
-=[7]=- Bot Password: 0         - Password protection for Commanding the bot remotely (0 = OFF).
-=[8]=- Pulse Check : ON        - Toggles checking that FigMon and CommsGuard are running.
-=[9]=- Citadel Menu: Brief     - Can be set to verbose for a more descriptive menu.
-=[A]=- Self Bot SS : OFF       - Send self botted command messages over SS instead of echo if ON.
-=[B]=- Reload Jump List        - Reloads the list of sectors from GAMENAME_JUMPLIST.txt into memory.
-=[C]=- Next Sector : Not Set   - Sets the next sector to visit in the jump list.

INSTALLATION
-------------
Place the readme, and the .wav file in your TWX root folder.
Place the script in your scripts folder.

When you run Z-Bot for the first time it will ask you for your Botname. Enter a 3 or 4 letter Botname and press ENTER.
It then creates a new z-options.cfg file in your TWX Root where you can edit your configuration settings later.

Recommended Scripts to work with Z-Bot are Z-FigMon, Z-Login, Z-PDriver and Z-SectorLister among others.

Using AUTOMATE to run PDRIVER automatically once or twice a day.
----------------------------------------------------------------
1. Create an entry in Z-Options.cfg for Z-PDriver in the EXTERNAL SCRIPTS section to make pdriver (semi) bottable.
   Example:    SCRIPT:  RESOURCE    pdriver         scripts\z-pdriver.cts
2. Run PDriver and set it's settings the way you want them to run.
3. Find the GAMENAME_z-pdriver.cfg file in your TWX root and rename it to GAMENAME_z-pdauto.off. (where GAMENAME is your database name)
4. Press the AUTOMATE hotkey in Z-Bot (default is SHIFT-U) to bring up the AUTOMATE menu.
5. Make the following selections/settings in the menu:
	[1] Trigger Type - should be:  Time - run every 12 hours  or  Time - run every 24 hours.
	[2] Time Trigger - set it to the appropriate time in the appropriate format as described when entering the trigger.
	[3] Command Line - should be:   pdriver   (as set in the z-options file in step 1)
	[4] Start on Planet - should be set to the planet number you will be running PDriver from. (optional - will put you on the planet if u are in sector)
	[5] Rename File -  should be:     GAMENAME_z-pdauto.off GAMENAME_z-pdauto.cfg    (2 filenames separated by a space)
	[0] Status - Should be set to ACTIVE - this turns automation on.
	[G] GO!  (Save and exit) - Saves the settings and returns to normal bot operations. (Automate will kick in at the time you set in step 5.[2])

Note: AUTOMATE will rename the GAMENAME_z-pdauto.off to GAMENAME_z-pdauto.cfg and run PDriver. 
      PDriver will grab its settings from the GAMENAME_z-pdauto.cfg file and then rename it back to GAMENAME_z-pdauto.off.
      This allows you to use pdriver for other purposes between automated runs with other settings without conflict.
	  Just make sure you are in sector with the planet (or on the planet) when its time to run.


Settings for AUTOMATE to automatically furb a red casher.
---------------------------------------------------------
Automate is  : ON
Command Line : furb [!] /dc
Type         : Text Trigger
Trigger      : Busted in Sector
Return Var   : [Sector ] {..}
Strip Text   :
Constant 1   :
Constant 2   :
Start Planet : None

Note that the Furb ship letter must be set in the options menu (TAB by default) before using the furb command this way.


GENERAL HINTS, TIPS and SUGGESTIONS.
------------------------------------
Z-Bot is not just a bot. 
It is a Control Centre for all you do in Tradewars.
It gathers in-game information in the background and uses it for the commands and options it makes available to you and your other scripts. 
It has many options and features. Too many to learn all at once.
Here are a few observations for the new Z-Bot user.

* Use the Movement system to get around the universe. Default hotkeys are [ - Mow, ] - Charge, } - TWarp. These hotkeys are a fast and efficient means of getting around and offer many features from a single interface. They are also bottable commands.
* Use the HELP VERBOSE command from your BOT command prompt (Default key is [>] to raise the BOT prompt) to get a general idea of the INTERNAL commands you have available and a brief description of what they do.
* Use the "HOTKEY Menu" hotkey (default is [SHIFT-K]) to see what HOTKEYS are available to you.
* There are many features in the Z-Bot. Spend some time in a quiet game getting curious with what things do. Play around with commands and hotkeys. Get to know the Bot as much as possible.
* Many options can be configured in the BOT OPTIONS Menu. Use the BOT OPTIONS hotkey (default key is [TAB]) to view and change these settings.
* You can add your old favourite bottable scripts to the Z-Bot. Just copy them to your TWX\scripts folder, and make an entry in the z-options.cfg file (found in the TWX root). You will see other entries for external scripts all together. Use these entries as examples as you add yours.
* You can add your own standalone scripts to the Standalone scripts menu for easy access and execution by editing the z-*.mnu files in the TWX root. The Standalone scripts menu system is completely unlimited. You can make a vast menu system with it for all your scripts.
* You can rearrange the hotkeys (all keys are configurable in the z-options.cfg file) to suit your needs and taste.
* Use the new Z-Panel to see crucial game information updated on the fly. Use the Panel hotkey (default is [SHIFT-I]) to toggle the panel on and off.
* Get to know the Z-SectorLister Script that came with the ZedPack. Use it to create all your sector lists for use with the Z-Bot and ZedPack scripts. It is powerful and versatile once you get used to it.
* The Z-Bot (and many ZedPack scripts) works at its best with a full ZTM. Use your GameInfo Hotkey (Default is shift-G) and look at the "Zero Warp Sectors" entry at the top left. It should be 0 after a good ZTM, or as close to 0 as possible.
* Use the CLEARTWX.CMD (Windows batch file script) that came with the ZedPack to clean up after a game. It will list all the files (in the TWX root) created by the ZedPack, Z-Bot, and other scripts for that game, for your approval for deletion. The file is source code so you can see what it does.
* Have Fun !

Kindest regards
Archy (Zed)

---------------
## CHANGELOG ##
---------------
1.01
----
Initial Release.

1.02
----
* ADDED Key assignments to the Z-Options.cfg File.
* ADDED TWarp Hotkey and bot command.
* ADDED T, M, C, and L shorthand bot commands for Twarp, Mow, Charge, and Land.
* ADDED LASTSECTOR destination option to the Move commands. Mow, Charge, and TWarp will record the current sector as the last sector before moving. 
* RESET now resets the current script menu to Main Menu and re-reads the zp_main.mnu file into memory.
* Fixed Mode RESET after script termination.
* Tidied up the Options Menu.
* ADDED some Log entries.

1.03
----
* Set selfbot commandline to lowercase.
* ADDED a Subspace message for when a player is added to the Corpy List.
* Fixed LASTSECTOR check to see that there is an existing lastsector.
* Fixed Crash when file not found in script menu.
* Fixed stray enter key being sent at stardock prompt when charge/mow/twarp key is pressed and then cancelled.
* Moved Transwarp check from twarp routine to startup routine. (keeping things quick at critical times)
* ADDED ability to send bot commands via personal message.
* ADDED CHANGESS bot command for manually changing a remote player's subspace channel.
* Fixed AUTOSS will now attempt to set a channel within 60 seconds of a reset.
* Fixed Charge/Mow/Twarp destination screen. (was not displaying some unavailable options that should have been displayed dimmed)
* ADDED trigger to add corpy to the list as they join the corp.
* ADDED a CLASS0 bot command for locations and backdoors of Class 0 Ports.
* ADDED the bot command TOW to hook a tow on a ship in sector.
* ADDED Hotkey for Hook & Tow - default is CTRL-J

1.04
----
* Fixed changess command continuing into the class0 command.
* ADDED a reminder to the changeSS response that AutoSS is set to off.
* ADDED VER bot command to display current VERSION information. FigMon 1.27 and above will also respond if running.
* ADDED TOPOFF bot command and hotkey for topping up fighters on your ship from fighters in sector.
* Fixed possible trigger exists crash when charging/mowing.
* ADDED a check for arriving at the destination sector for charge/mow and a message if it failed.
* ADDED IG bot command for turning the ship's Interdictor Generator ON or OFF.
* ADDED a botname check to the startup routine. If no botname is set Z-Bot will exit.
* ADDED the $BOT_NAME variable to the game data config file for other bots' commands.
* ADDED the Xfer Hotkey for transferring Figs, Shields and Mines between corpies in sector.

1.05
----
* Fixed default menus created at first run which had .ts instead of .cts entries.
* ADDED a hotkey to display a banner text file over FedComm. (default z-banner.txt in TWX Root)
* ADDED the DC bot command. (Deposit Cash)
* ADDED the WC bot command. (Withdraw Cash)
* Fixed Pdrop return trigger already exists crash.
* Fixed Citkilla looping out of control.
* ADDED Citadel Menu Hotkey and several Citadel (siege) Macros.
* Significant speed & safety improvements to twarp routines.

1.06
----
* Fixed erroneous "file not found" error in script menu after running an xtra bot command.
* Fixed Charge/mow/twarp to work with or without spaces between options
* Fixed error and crash when a disconnect/reconnect occurs with the bot running.
* Bot commands sent via PM will now respond via PM.
* Fixed charger/mower not working after a "so what's the point" error.
* ADDED Plimp bot command for corpy scrubbing.

1.07
----
* Corp checking is now friendly to corpies with more than 6 chars in their name.
* Fixed various problems with PM messaging not cancelling after use and sender name = 0.
* ADDED Bot Password for use when using the private message system for botting a player.
* Fixed charge/mow/twarp crashing with bad message recipient after using the PM bot command option.

1.08
----
* Fixed scripts command not displaying correctly
* ADDED Active Script list to Status screen output.
* Fixed OREUP "Goto label not found" error.
* Changed mode for OREUP to OREUP.
* ADDED FIND bot command to find 6 nearest fuel ports.
* ADDED STOPALL command to stop all non-system scripts and reset to GENERAL MODE.
* ADDED unlimitedgame variable to the database cfg file for mombot compatibility.
* ADDED $stardock variable to the database cfg file for mombot compatibility.
* ADDED Subspace channel to the Status display. (Updates with AutoSS, ChangeSS and when a ss message is sent).

1.09
----
* Fixed possible misinterpretation of an outgoing ss message as a command.
* Fixed the unlimitedgame variable so that it "is" actually compatible. :-|

1.10
----
* ADDED bot command CN9 to check and set the cn9 setting to SPACE.
* Moved/added ABORT DISPLAY/ANIMATION/COMPACT MESSAGES/WARPDRIVE checks to RESET command.
* ADDED a trigger to trap PM messages going to M.A.I.L. box (offline player).
* Reset message mode to subspace when player uses hotkeys. (sometimes it was left set to the last player who botted using PM)
* ADDED bot command DEPLOY for deploying fighters in sector from a planet.

1.11
----
* Fixed incorrect banner file name created during first run.
* Fixed TWarp trying to move into target sector after a direct jump. (you are already there)
* Fixed Double arrived message when twarping adjacent.
* ADDED a comms check for approximately every 30 minutes.
* ADDED the CLEARALLBUSTS command to unconditionally clear all your busts.
* ADDED the BUSTUP bot command for raising the experience of red players.

1.12
----
* Fixed incorrect variable in Evac.
* ADDED a hotkey for blind Twarp (no safety checks but fast) - add the following to the z-options.cfg file: BLINDWARPKEY: {
* ADDED V screen check for stardock at initialise.
* ADDED the AVOIDS bot command to get a list of avoids from your corpys.
* Set the FIGS, MINES, and LIMPS commands to a separate mode.
* ADDED option to change Figmon broadcast setting in options menu.

1.13
----
* Fixed QSet hanging after sending ss message.
* ADDED defaults for the hotkeys (in case they are missing from the options file).
* ADDED the XPORT bot command.
* ADDED the DISR bot command to disrupt enemy mines in all adjacent sectors.

1.14
----
* ADDED ability to jump off dock, get an xport ship list, and redock again to the xport command.
* Fixed Hook and Tow hanging if you are already towing a ship when the command is run.
* ADDED a Disrupt hotkey (CTRL-D by default) - add the following to the z-options.cfg file:  DISRUPTKEY: CTRL-D
* ADDED X bot command.. same as XPORT.
* ADDED the $_ck_ptradesetting variable for ck_planetary_nego.
* Fixed possible crash in mow/charge/twarp/blindwarp commands when a letter and number are entered as the target sector.

1.15
----
* Project-Z name changed to Z-Bot.
* ADDED ENTER key to exit from Options menu.
* Fixed incorrect colouring on mow/charge/twarp screen.
* Changed most default hotkeys from CTRL-key to SHIFT-key.
* Z-Bot now sets the timeoffset variable for AutoSS.
* Charge/Mow and TWarp should work from Alpha and Rylos ports now.
* ADDED WAVECAP, CAPTURE, and KILL macros (for mow, charge etc options) to the Z-Options.cfg file for editing.
* ADDED the PLIST bot command for getting a list of planets in sector over subspace.
* ADDED Anti-Self Destruct protection.
* ADDED a log entry for when EVAC is activated.
* Replaced blank lines with dashed lines in scan command output.

1.16
----
* Fixed incompatibility with Mombot WSST. (Changes were necessary to WSST itself)
  The edited WSST is now included with Z-Bot and is named zwsst.cts. (ALL credit to LoneStar for an immortal script)

1.17
----
* ADDED the AMTRAK bot command for finding all adjacents to fedspace and the MSLs.
* ADDED Rylos and Alphacentauri variables to the gamedata config for Mombot compatibility.
* Fixed bad prompt problem when twarping off alpha or rylos
* Fixed hangup when mapping a route using twarp.
* Fixed a conflict with the pulse and the Pdrop, Citkill, and Evac commands. (The AutoSS was not changing channels)
* ADDED an Edited version of Mass Upgrade to work with the bot. (All credit to Remco Mulder for a fine script)
* ADDED an entry for WSST to the default z-options.cfg file created when Z-Bot is first run.

1.18
----
* ADDED the SAFETYNET bot command to turn ON/OFF the safetynet. (xports you to a safeship when under threat)
* ADDED a hotkey to toggle SAFETYNET. (SHIFT-S by default) - add the following to the z-options.cfg file:  SAFETYNETKEY: S
* ADDED the SAFESHIP bot command to allow setting the safeship remotely.
* ADDED the SAFETYNET status to the STATUS screen.
* ADDED Limp trigger to PDrop routine.
* ADDED code to the Bot and to Figmon so that they keep each other running if 1 or the other stops (checks approx every 10 mins)
* Fixed Xport Update option so that it doesnt interfere with WSST when it xports from ship to ship.
* ADDED IG check to XPORT command.
* Removed the MSLs from the AMTRAK list.
* ADDED the MSLS bot command to create a list of MSLs.
* Tidied up the Hotkey screen
* ADDED a hotkey to display the HotKey Menu - add the following to the z-options.cfg file:  HOTMENUKEY: K

1.19
----
* Fixed possible hangup when auto changing subspace channels with lots of alien activity.
* Fixed hangup when xporting and porting. (caused by the IG check)
* Fixed problem of porting on trade port at stardock when xporting in and porting from another sector.
* ADDED an Options Menu command to turn off the pulse check. (Comms/Time check) This will not affect the AutoSS check which can be set separately.

1.20
----
* ADDED SS output for MSLs and AMTRAK commands.
* ADDED an Information Screen available through a hotkey ([G] by default). - add the following to the z-options.cfg file:  INFOKEY: G
* ADDED Pulse Check status to the Status screen
* ADDED Time stamps approx every 29 minutes. (enable/disable with Pulse Check on/off)
* ADDED eProber on a hotkey for eprobing a list. - add the following to the z-options.cfg file:  PROBEKEY: E
* ADDED a hotkey to do a short ZTM (using a sector list) - add the following to the z-options.cfg file:  ZTMKEY: O
* Fixed Planet Percent ($PTRADESETTING) variable. CK Nego should not ask for this anymore.
* ADDED Server Shutdown triggers. (Bot will terminate active non-system scripts, reset, and shutdown). Turn these triggers off temporarily at the Options Menu (TAB)
* Tweaked the PDrop adjacent sector selection routine.
* ADDED Pdrop Return Delay setting to the Options menu.
* ADDED the OVERLOAD bot command for checking sector planetary overloads and MSL sectors containing planets.
* ADDED the MAX bot command for upgrading ports to the max, with or without experience.

1.21
----
* Fixed Charge/mow/twarp will scrub when porting at class 0s.
* ADDED the FORCE parameter to the bot SURROUND command which causes it to ignore enemy limps.
* ADDED the CLEAR bot command to disrupt mines, clear limpets, and do a surround of adjacent sectors.
* Fixed hangup when Game Info key is pressed and stardock sector has not been visited.
* Fixed FIND command finding no-port sectors.
* ADDED BUY and NEG bot commands to call CK's scripts to buydown and planet negotiate.

1.22
----
* Timecheck now occurs on the hour and half hour with a cuckoo at the hour if sound is on.
* ADDED Timecheck option to options menu (Timecheck is now set separately from the pulse check).
* ADDED CREEPER MODE hotkey ([C] by default). - add the following to the z-options.cfg file:  CREEPERKEY: C

1.23
----
* ADDED the ATTACK hotkey. ([A] by default). - add the following to the z-options.cfg file:  ATTACKKEY: A
* ADDED an entry in Z-Options.cfg to allow customising the attack macro.
  Add the following 4 lines to the bottom of your Z-Options.cfg file:

# ATTACK HOTKEY Macro
#---------------------
ATTACK: q q q z 0* q z 0* q z 0* a t y n q z <WAVE> n y * a t n y q z <WAVE> n y *
#

* Fixed Safetynet not recognising corpies with names longer than 6 letters.

1.24
----
* Fixed intermittent error at line 9168
* ADDED alert sound for when Emergency Protocol is activated (SafetyNet)
* ADDED the AVOID and UNAVOID commands.
* Fixed External command handler. (was clearing command parameters too quickly)
* ADDED SILENT MODE to suppress SS messages from the bot.
* ADDED the RECALL command to collect all figs in sector and place on a planet.
* ADDED the DROPALL command to drop all figs on ship into sector.
* ADDED the FURB command to get a furb ship from dock and tow it back to start sector.
* ADDED Furb settings to options menu and status display.
* ADDED ONLINEWATCH to report online status changes every 5 minutes.
* ADDED the WATCH bot command to turn ONLINE WATCH ON and OFF remotely.
* ADDED the NMAC command to run a macro a given number of times.
* ADDED HERALD TURNS option to display turns left over SS each hour.
* ADDED CLIMP command to drop max corporate limpets in sector (change existing limps to corporate).
* Fixed PLIMP command to drop max personal limpets in sector (change existing limps to personal).
* Sorted HELP LIST and HELP XTRA output alphabetically.
* ADDED Z-HelpList.cfg file for custom HELP LIST output. (If file exists, contents replace HELP LIST screen)
* ADDED the GAS command to find and buy fuel for the ship.
* ADDED the FIND FUEL hotkey. ([F] by default). - add the following to the z-options.cfg file:  FUELKEY: F

1.25
----
* Fixed TopOff Hotkey not responding after use.
* Timecheck only happens if mode is "GENERAL".
* Fixed invasion commands - PE PXE etc.. Were not firing photons.

1.26
----
* Fixed intermittent comms staying off after external command.
* Fixed some incompatibilities with New TWGS
* ADDED Ship Cap Hotkey. ([P] by default). - add the following to the z-options.cfg file:  CAPKEY: P
* ADDED Ship Cap and Shipstats options to the options file for naming the appropriate script to be run.
  Add the following to the z-options.cfg file:
  
  SHIPSTATS: _ck_ship_stats.cts
  SHIPCAP: __ck_ship_cap.cts

* Fixed movement keys will now work from Terra (mow, charge, twarp & blindwarp).
* Fixed Deploy, Recall, Dropall & Topoff commands retain figtype setting of existing figs in sector.
* ADDED the SENTRY bot command to refill a defender ship with fighters from a planet automatically when attacked.
* ADDED the DENSITY bot command to display a list of known high density sectors.

1.27
----
* ADDED ability to choose a banner to display if more than 1 is specified in z-options.cfg
* ADDED the LIMPET ALARM.
* Fixed Shutdown trigger to work with new "Server will shut down" notice.
* ADDED the SENDMAP and GETMAP bot commands to facilitate sending warpspecs over SS.
* Fixed Creeper Mode display sometimes corrupted by prompts displaying too quickly.
* ADDED the ALIENS bot command to send a list of known alien sectors over subspace.
* Fixed new AVOIDS screen not displaying botted avoids.
* ADDED categorised command lists combining internal and external commands. Available categories are COMBAT, CASH, RESOURCE, DATA, GRID, UTILITY. The Modes are used for external commands.
* ADDED Installation notes for Z-Bot and Z-Login to the Zed-Pack.
* Fixed a problem with the screen not displaying correctly in Putty Telnet (after a clearscreen).
* Cosmetic fixes to the Options menu and the Hotkeys screen.

1.28
----
* ADDED the CFIGS and PFIGS bot commands for changing figs to personal or corporate.
* ADDED a menu to the EPROBER hotkey to allow a choice of Entire universe or sectorlist file, and to allow starting at any sector in the list/universe and to allow parsing the sector list in reverse order.
* ADDED report and sector output files to EPROBER. GAMENAME_eProbeReport.txt and GAMENAME_eProbeSectors.txt.
* Cosmetic fixes to the CITADEL menu.
* ADDED ability to have sub teams. All corpies with the same team name setting will respond to commands issued to that team name over subspace. The team name can be set via the options menu or via the new TEAM bot command.
* Changed MSL SectorParameter to MSLSEC for compatibility with other scripts.
* Fixed z-banner.txt file not being made correctly if found to not exist.
* ADDED the SETPARM and CLEARPARM bot commands for setting and clearing sector parameters.
* ADDED the LISTPARM bot command for sending a list of sector parameters over subspace.
* ADDED an echo for when you are in the last rob/steal sector (requires Z-FigMon 1.32 or higher).
* ADDED a command count to the help list screens.
* ADDED the COUNTBUSTS bot command to display a count of busted sectors, a list of busted sectors, and the last rob/steal sector over subspace.
* Fixed XFER key not working with corpies with long names.
* ADDED the SETMATRIX and MATRIX bot commands for checking the busted status of red cashing sectors. (requires Z-FigMon 1.32 or higher).
* Fixed XFER player selection to not offer yourself as a candidate to transfer with.

1.29
----
* ADDED the VIEW MATRIX hotkey. - add the following to the z-options.cfg file:  MATRIXKEY: V
* Fixed the TOW bot command getting snagged if a ship is already in tow.
* ADDED a message to the BUSTUP bot command to tell the remote player that the bot is busting up.
* ADDED the Rob Multiplier to the Game Info Screen.
* ADDED the JUMPLIST capability to the movement hotkeys. Create a list of sectors to jump to and the movement keys will have a new option [J] to jump to them. The jumplist must be named GAMENAME_JUMPLIST.txt and be located in the TWX Root. You can force the bot to re-read the list and you can set the next sector in the list to jump to at the options menu.
* ADDED GAS option to move commands to buy gas if there is a fuel port in the destination sector.
* Fixed TWARP hotkey hanging if the adjacent jumpsector for an unfigged destination happens to be your current sector.
* ADDED the BUSY bot command to check if a remote bot is busy before issuing commands that may disrupt it.
* Fixed MOVE commands not reporting results when botted.
* Fixed some move commands (with short names) not passing parameters correctly.
* ADDED the NDMAC bot command to run a macro a number of times with a pause between each iteration.
* ADDED the SENDLIST and GETLIST bot commands to allow sharing of the jumplist over subspace.
* ADDED the SETNEXT bot command to allow remotely setting the next sector to visit in the jumplist.
* Rearranged help screens into 4 columns.
* ADDED the HOOK bot command to hook tow onto a manned ship.
* ADDED the HOOK MANNED hotkey. - add the following to the z-options.cfg file:  HOOKMANKEY: W
* ADDED countbusts now writes the busted sectors to GAMENAME_busts.txt.
* Hotkeys using the SHIFT key now show as SHFT-A or SHFT-B etc on the hotkey screen. You can now set the shifted hotkey in the z-options.cfg file using just the letter eg: A   or SHFT-A.
* ADDED a splash screen.
* Fixed Buy and Neg commands hanging the bot if stopped prematurely.
* ADDED the PRETAX bot command to pretax you at the minimum possible and to unlock your ship.
* Fixed bot move commands not remembering last sector.
* ADDED Interactive Subprompts status to the Game Info Screen.
* ADDED the STOPALL hot key to stop all non-system scripts - add the following to the z-options.cfg file:  STOPALLKEY: L
* ADDED clearallbusts now deletes the GAMENAME_busts.txt file
* ADDED the DAMAGE bot command to report on quasar damage.
* ADDED abort key (BACKSPACE) to find fuel hotkey and gas bot command.
* ADDED the MCICS bot command to list equipment buying ports with high mcics. Requires _ck_equip_haggle_tracker supplied with the Zed-Pack.
* ADDED the UNLOCK bot command - does exactly the same as the pretax command.

1.30
----
* Fixed several hotkeys sending responses to the last corpy to PM bot you instead of subspace.
* Changed DAMAGE RECORDING now defaults to on.
* ADDED Damage reports now write to a file in the TWX Root named GAMENAME_DAMAGEREPORT.txt.
* Fixed TWARP intermittently stalling in turn games.
* Removed the pulse when the bot is disabled using CTRL-Z.
* WC, DC, and DEPLOY now recognise K as 1000 in addition to T
* Fixed the BOTONOFF key was stuck on CTRL-Z when the bot was turned off.
* ADDED BOT OFF bot command to turn the bot off remotely (puts the bot in a dormant state.
* ADDED (to figmon 1.33) FIGMON BOT ON command to load the bot if it is not currently running.
* Changed the MCICS bot command to MCIC.
* MCIC command now writes to GAMENAME_MCICS.txt in the TWX root.
* Changed AVOID and UNAVOID bot commands now accept several sectors instead of just 1 sector.
* ADDED $colonist_regen variable now read from Asterisk screen and written to the GAMENAME.cfg file.
* ADDED botname is now written to a file called GAMENAME.stbot in the TWX Root.
* MOM_GAMENAME_Busts.txt is now DELETED when the clearallbusts command is executed.
* ADDED the ROB command to rob a port. (Z-bot can now be used as a Red-Rider with Z-Pdriver)
* Fixed date calculations to work with the new game year.
* Changed commands that need to run from the COMMAND prompt can now be run from the Galactic Bank. (you will be moved to the COMMAND prompt)
* Changed the MAX command now withdraws and deposits cash as needed from the citadel if it is started from the citadel.
* Fixed MAX command missing amt to upgrade due to speed.
* Fixed XFER command not transferring shields if the amount wasn't exactly 16000.

1.31
----
* CHANGED Photon/enter commands (PE PEL etc..) will not buffer if DAMAGE is on. This will slow the commands down slightly but will allow the DAMAGE function to capture the damage info.
* ADDED Key configuration for the view MATRIX KEY.
* ADDED sectors done/total sectors  display to the JUMPLIST SS output.
* ADDED ability to specify maximum MCIC to the MCIC command.
* ADDED the bot sends a message when it arrives at the new subspace channel via the auto ss changer.
* ADDED the COMMS command to turn comms ON.
* CHANGED MCIC default value to -48.
* ADDED the REFILL command to refill figs and shields from a planet.
* ADDED ss message when CITKILL is turned on.
* FIXED CITKILL now checks your prompt when it first runs.
* ADDED MCIC list is now backed up to GAMENAME_MCICS-last.txt.
* ADDED the GAMESETTINGS command to retrieve the game settings and place them in a file.
* FIXED DISR command hanging up if you run out of disruptors.
* CHANGED CHANGESS command will now attempt to change to the automatic ss changer channel when the auto channel changer is set on and no parameter is specified.
* ADDED the BASE command to change the bots base sector remotely.
* ADDED the SAFESECTOR command to change the bots safe sector remotely.
* ADDED EMPTYHOLDS display to the QSS command.
* ADDED the SCRUB command to twarp you to your safe sector and then to base.
* ADDED ss message when TOPOFF completes.
* FIXED BLINDWARP jump hanging up if you fuse.
* FIXED BLINDWARP sometimes erroneously deciding you don't have enough fuel.
* FIXED MOW/CHARGE/TWARP/BLINDWARP GAS option not working if not at the command prompt.
* CHANGED the HELP SYSTEM now displays self botted help (using the > key) for help lists and internal commands via an ECHO. External command help still displays over SS or PM.
* FIXED SHIP UPDATE option now works when using the X or XPORT commands.
* ADDED SCRUBZONE command to list all sectors with personal limpets.
* ADDED MODE changing support for external scripts. (Less interference from the bot while they are running).
* CHANGED SELF BOTTED HELP will now display the self bot key instead of the botname when describing command usage.
* CHANGED FIGS/MINES/LIMPS commands no longer change to black and white mode (the speed difference is negligible).
* ADDED an "ARE YOU SURE" safety to the BLINDWARP function.
* ADDED new Z-Strip script to the double tap menu and z-options file. (Created when Z-Bot is run for the first time).
* FIXED occasional problem of z-bot shutting down when using the TOPOFF command/button.
* FIXED SURROUND marking a sector as figged when it didn't fig it.
* CHANGED the eProber can now be run from any sector and optionally refill eprobes at stardock using TWARP. (If started from a citadel it will refuel itself from the planet).
* ADDED an SS Broadcast option to the eProber.
* CHANGED eProber now backs up its report and sector files before recreating them. (look for their .bak files in the TWX Root).
* ADDED a photon option to the Citadel Menu.
* Changed the FURB command now requires the DELIVERY SECTOR as the first parameter.
* FIXED eProber hanging on "No route within" - "Clear Avoids?" prompt.
* CHANGED SURROUND command and option now drops figs in the current sector as well as adjacents.
* CHANGED TWARP now recognises when its caught in an interdictor.
* FIXED External commands sometimes not resetting mode when finished.
* FIXED SAFETY NET response to Photon attacks.
* ADDED new ECHOS for TERRA, STARDOCK, ALPHA and RYLOS. (Available in Options Menu)
* CHANGED STARDOCK OPTION on the MOVEMENT MENUS now displays in RED if you are not COMMISSIONED.
* FIXED LAND command to handle TERRA.
* ADDED the NEAR command to display the 16 nearest figged sectors to a specified sector.
* ADDED extra information to the MCIC report.
* CHANGED the default z-banner.txt created by the bot when first run. (delete the existing z-banner.txt to update yours)
* FIXED large banners not displaying fully on servers where you have a high ping.
* ADDED the FEDWATCH command to allow a corpy to report activity in Fedspace (Usually Terra or Stardock).
* ADDED a flashing reminder when SENTRY mode is started of what key to press to exit.
* FIXED Citadel Menu intercepting the Citadel Menu Key when not at the Citadel Prompt.
* ADDED ONLINE WATCH features anytime the # key is pressed.
* FIXED Hotkeys activating while messaging.
* ADDED A USER-DEFINED HOT KEY SYSTEM for running INTERNAL commands and EXTERNAL scripts from a hot key.
  Add the following to your z-options.cfg file (below the last entry in the KEY ASSIGNMENTS section).

	HOTLISTKEY: H
	#
	# USER DEFINED HOTKEYS
	#----------------------
	#      Key       Type    Command/Script                 Description
	#--------------------------------------------------------------------
	# Example User Defined Hotkey entries. Add your own as needed.
	HOTKEY: Q       INTERNAL qss                            QSS
	HOTKEY: Y       EXTERNAL scripts\Z-SectorLister.cts     SectorLister
	#

* FIXED MOVE system remembering previously used options (such as Call saveme).
* ADDED EXTERN time to the GAMEINFO display (as last seen by FigMon)
* ADDED PRICES command to display Hold, Fighter and Shield prices as collected each reset.
* ADDED the GLEAN command to periodically glean figs from a planet.
* FIXED Adjustment to SENDMAP and SENDLIST timing.
* ADDED the [N]-Land option to all MOVE commands to land on a planet.
* FIXED MOVE commands will no longer lock up if the target sector is avoided.
* ADDED the NEWS command to summarise the daily logs.
* ADDED Photon Duration to the GAME INFO screen.
* FIXED BANNERS displaying over subspace instead of fedcomm.
* ADDED the SHIPS command to display a list of ships within a specified XPORT range.
* ADDED the LASTBOTKEY hotkey to display and optionally execute any of the last 9 self bot commands.
  Add the following to your z-options.cfg file in the KEY ASSIGNMENTS section:    LASTBOTKEY: (
* FIXED Help CATEGORY displays not showing internal commands.

1.32
----
* ADDED announcements to the "no hotkey zone" when messaging.
* FIXED SHIP UPDATE leaving you at the Computer prompt (and not actually updating the ship info).
* ADDED the AUTOFURB command to automatically kill a ship towed into sector. (ON/OFF)
* ADDED the ALL parameter to the NEWS command to summarise all news from game start to now.
* FIXED "trigger exists" error in PDROP, EVAC and CITKILL (introduced by the mode command last version).

1.33
----
* ADDED more spoof protection to SAFETYNET (both bot command and external script).
* FIXED problem of z-bot changing ship password. (This problem was actually in the z-login script. - Please update z-login ASAP)
* FIXED GLEAN sometimes aborting.
* FIXED more work on stabilising GETMAP/SENDMAP when used over a bad connection.
* ADDED MCIC ECHOS. These turn on in the Options Menu with PORT ECHOS.
* FIXED FEDWATCH now displays the full name of the player warping in to sector.
* ADDED SENTRY mode now accepts STATUS RESET MODE BUSY and OFF commands via personal message as well as via SS.
* FIXED problem with the OREUP command if you havent visited the sector and arrived on a planet.
* FIXED CITKILL/PDROP/EVAC now turn off with a RESET.
* FIXED MOVE keys no longer put you at the command prompt if dont specify a sector or an action.
* ADDED the EVACUATE command to evacuate all movable planets to a specified sector.
* FIXED comms left off after OREUP.
* ADDED the MOVESHIPS command to evacuate all ships to a specified sector.
* ADDED the PWARP and P commands to pwarp a planet to a specified sector.
* ADDED the CSHIP command to change your current ship to corporate owned.
* ADDED the TURNS command to display your turns (and time remaining) over subspace.
* ADDED the PINFO command to display planet information over subspace.
* ADDED the INFO PANEL HOTKEY to show/hide the INFOPANEL. (Requires the new Z-Panel script) - add the following to the z-options.cfg file under KEY ASSIGNMENTS:   PANELKEY: I
* ADDED a QSS to the UPDATE SHIP routine to keep the panel updated.
* CHANGED MAX and ROB commands to hold 2,000,000 credits when depositing.
* ADDED the DELIMP command to clear enemy limps in the current sector and optionally place some of your own.
* FIXED the OREUP command will return you to the CITADEL prompt if that is where you started.
* ADDED triggers to CITKILL for lift off and blast off.
* ADDED the SEED command to set a seed for the AUTOSS system.
* ADDED the PROMPT command to change to a specified prompt or display the current prompt.
* ADDED the verbose option to the HELP command to display a descriptive list of internal commands.
  Note that:  help verbose, help all, or help commands  can be used to get the descriptive list.
* ADDED the FS command to TWARP you to Fedspace via an adjacent if necessary.
* CHANGED the QSET command now recognises M for millions, T or K for thousands.
* FIXED CITKILL hanging if there is an enemy mine in sector.
* ADDED Swath info update (/) after OREUP has completed.
* FIXED LAND command not working from a planet/citadel prompt.
* ADDED DECASH option to FURB command.
* FIXED PROMPT command not working from the NavPoint prompt.
* ADDED AUTOFURB now reports current holds.
* FIXED FURB command causing you to "wander around stardock". >.>
* ADDED the CLEARBUST command to clear the bust flag in a given sector.
* ADDED the SETBUST command to set the bust flag in a given sector.
* ADDED FURB command now gives corpy 20 fighters (and replenishes at STARDOCK).
* ADDED ZBOT ON command to Z-FIGMON to kill and load the z-bot. Usage 'botname zbot on. (over subspace)
* UNLOCKED the AUTOMATE system for running commands automatically daily, twice daily, or based on a trigger. (Hotkey and bot command)
   Add the following line to your z-options.cfg file under KEY ASSIGNMENTS:     AUTOKEY: U
* ADDED settings Snapshot load/save to AUTOMATE menu and the load option to the AUTOMATE command.
* ADDED DOCK SAFER option to the Options menu. When ON, the MOVE system will double check STARDOCK exists if you try to move and dock there, before you leave.
* CHANGED INTERNAL commands that are run from the self bot prompt. They now generally use ECHOS rather than SUBSPACE for screen output.
* ADDED TIME LEFT display to the TURNS command.
* CHANGED Help list sorts default to not done when the Z-Bot starts. (To speed up bot initialisation). Use HELP SORT to sort the lists. Lists stay sorted until a bot reset.
* ADDED an option to z-options.cfg to toggle HELP LIST SORT at startup. Add the following line to the z-options.cfg :    SORTHELP: OFF
* FIXED TWARP command/hotkey not working from the Stardock port (buy figs etc).
* ADDED the /d option to the SCAN command to only use the density scanner.
* ADDED the PORTCHECK command to send a commerce report over subspace.
* ADDED the SELLSHIPS command to sell ALL ships in the StarDock sector.
* ADDED StarDock FUEL SELLING/NOT SELLING status to the GAME INFO screen.
* ADDED configuration file help to the HELP command.
* ADDED 2 editable CONSTANTS to the AUTOMATE system. (Variables that are set and stay the same value)
* CHANGED the X and XPORT commands to be a LOT faster.
* CHANGED Z-Bot now asks new users for a Bot name, rather than Quitting until the new z-options.cfg file is edited. (Similar improvements also made to the Z-Login script)
* ADDED the ability to configure whether or not to use automatic setting of IG to ON.
* ADDED the STATUS screen now reports the LastRobSteal sector.
* CHANGED the SECTOR command now uses the current sector if none is specified.
* ADDED the DISPLAY command to send the current sector information over subspace.
* ALIASED the SCAN command with HOLO for Mombot compatibility.
* ADDED the MEGA command to MEGAROB a port in an MBBS game.
* ADDED an option to the Bot Options Menu to turn the LRS (Last Rob Sector) echos on or off.
* ADDED Last Rob/Steal Sector display to the Z-Panel window.
* Updated the Z-PDriver script to allow the Red Rider to use the new MEGA command.
* FIXED GAMESETTINGS command hanging up if you have a cloak.
* FIXED the * screen displaying twice when once is all thats needed.
* ADDED a choice to allow BANNERs to be sent to SubSpace as well as FedComm.
* UNLOCKED the DP command to photon adjacent based on density changes.
* UNLOCKED the TP command to TWarp/BWarp to an adjacent of the target, photon the target, and twarp back.
* UNLOCKED BBop to allow a planet rider to collect port info automatically as a corpy cashes with the planet.
* UNLOCKED the DEFIG command to remove an enemy fig from an adjacent FAST. (To avoid a pre-locked pdrop)
* UNLOCKED the VOLLEYS setting in the BOT OPTIONS menu to allow setting of how many waves to throw with the KILL option of the move commands.
  This also tells SAFETY NET to throw volleys before it xports out (if volleys is non-zero).
* UNLOCKED the ZMAC command which allows you to control the bot using a macro that uses the built in movement system (twarp/mow/charge).
* ADDED an option to toggle REMOTE ACCESS. (You cannot be botted if RemoteAccess is off in the Bot Options Menu.)
* ADDED an option in the Bot Options Menu to turn ON/OFF the PROXIMITY ALERT.
* ADDED the MOVESYS option to the HELP command to display information about the Movement System.
* ADDED Arrival Options to the TP command.

2.00
----
* FIXED Automate System Load Snapshot option reporting it loaded a file when it didn't.
* ADDED Photons launched report to the news.
* CHANGED ONLINE WATCH, FED WATCH and the TURNS command now use SubSpace if Self Botted.
* FIXED INFO PANEL crashes.
* ADDED the BANK command for handling Galactic Bank transactions.
* FIXED the Z-Bot not shutting down with a sysop initiated server shutdown.
* FIXED # key not working when bot is not in GENERAL or SENTRY mode.
* ADDED CHARGER now drops a fig at destination.
* ADDED G parameter to MODE command to reset the mode to GENERAL.
* FIXED Z-Bot doing a [C;] at the beginning of every TWARP in a turn game.
* ADDED TWARP drops a fig at the destination if it had to move in from an adjacent and it's not fedspace.
* ADDED the MAIN PLANET option to the Bot Options Menu. Many commands will use this if no planet is specified.
* ADDED MCICs to the CREEPER display.
* ADDED the [.] key to CREEPER mode to allow for a drop to the command prompt so you can interact with the game.
* ADDED "D" type to Standalone Menus to allow for DAEMON scripts (run in the background).
* ADDED If a SHUTDOWN is imminent within 1 minute, and if you are at your BASE sector and your MAIN PLANET is in sector, Z-Bot will LAND, PRETAX, and RETIRE you.
* ADDED CLV option for ONLINE WATCH to report experience, alignment, and corp changes.
* ADDED an ECHO when ONLINE WATCH is on.
* FIXED SERVER SHUTDOWN/DISCONNECTION routines not disconnecting/reconnecting correctly.
* ADDED LIMPET ACTIVATION warning (someone hits your limp). The warning is tied to `Limp Alarm' and `Alert on SS' settings in the Bot Settings. Also gives adjacents.
* FIXED GAMESETTINGS command not saving GAMESETTINGS file.
* ADDED ability to configure time between ONLINE WATCH checks.
* ADDED the LEAVE command to send the bot to the T menu for x seconds.
* ADDED Z-Bot stores CKs GAME SETTINGS as per the settings in the Bot Options Menu.
* ADDED the TAG alert for when a corpy scrubs at your scrubzone. (Must have Limp Alarm On - and preferably Alert on SS)
* ADDED MAX Bank Balance to the GAME INFO display and the Panel.
* ADDED the DELIVER command to pickup and deliver a ship using TWarp.
* ADDED a trigger for PHOTON DAMAGE to the TWARP system.
* ADDED the PLANET command for setting the Main Planet.
* ADDED the HERALDTURNS command to allow remote control of the HERALD TURNS setting.
* ADDED HOURLY and TOP OF THE HOUR triggers to the AUTOMATE system.
* FIXED LIMPET ALARM not turning off when scrubbed.
* ADDED the COLO WATCH HOTKEY to OPEN and CLOSE the new Z-Watch script. A colonist watch/calculator window.  - add the following to the z-options.cfg file under KEY ASSIGNMENTS:   WATCHKEY: Z
* ADDED the GAS command now searches the current planet for fuel if you are on one. Will also use the MAIN planet if you are in the base sector.
* FIXED bot crash on sudden disconnection (i hope)
* ADDED the OVERRIDE option to the HELP command to display a list of internal command overrides. Overrides are also marked on the lists with an asterisk.
* ADDED the ZBOT ON subspace command to Terrakit.
* ADDED RESCUE AVAILABILITY STATUS to the STATUS screen.
* ADDED LANDING functionality to the xport P option.
* FIXED Z-COLONISER dumping colonists when first run to clear holds.
* FIXED Z-RESCUE not answering CALLSAVEME by CK and perhaps some others.
* FIXED Z-FIGMON not responding to remote commands if your user name is the same as your bot name.
* FIXED EXIT command retiring you in the citadel instead of jumping to sector.
* ADDED the COMPILE command to create a list of upgraded ports.
* FIXED JUMPLIST system not allowing extra information on each sector line in the JumpList file.
* ADDED MINIMUM TURNS and MINIMUM FIGS to conserve in the Bot Options menu.
* ADDED the SPG (Smart Passive Gridder) command.
* ADDED in FIGMON now creates a GAMENAME_TEMPHITS.txt file of fighits since FigMon loaded.
* ADDED newly created z-options.cfg files will now contain an alias for RESCUE as SAVEME.
* FIXED Hotkeys interfering when creating corp.
* ADDED the SENDFILE, GETFILE, and LIST commands for sending pre-approved list files over subspace.
* FIXED SCAN command now returns you to the planet if you started there.
* ADDED the ability to edit the MINIMUM TURNS option using the TURNS command.
* FIXED NEWS command not showing destroyed ports.
* ADDED NEWS command now outputs to GAMENAME_NEWS.txt. (Backs up to GAMENAME_NEWS-backup.txt)
* FIXED BUY and NEG commands return you to the Citadel if that is where you started.
* ADDED a FAST callsaveme alternative to the Bot Options Menu.
* ADDED TURN HERALD now has messages and smilies (Z-Herald.cfg and Z-Smilies.cfg)
* FIXED TIMECHECK erroneous display.
* ADDED Both FS (Figs and Shields) option to the Xfer Hotkey. Also remembers settings between uses.
* ADDED a FAST XFER hotkey.   - add the following to the z-options.cfg file under KEY ASSIGNMENTS:   FASTXFERKEY: DOT
* ADDED XFER now works from the planet. Returning and refilling on the planet.
* FIXED REFILL now returns you to the Citadel prompt if thats where you started.
* CHANGED the Bot Options menu has been divided into multiple pages.
* ADDED additional options, fixes and improvements to the CITADEL Menu.
* ADDED PLIMPS and CLIMPS commands - swapped functions with PLIMP and CLIMP so that the former are putting down max limps, the latter only 1 limp.
* ADDED cfg files and log files for the ZedPack now listed in the HELP CONFIG screen.
* FIXED the MOVEMENT system now turns TWARP ON if it is off when you try to TWARP.
* FIXED EVACUATE command hanging with empty planets.
* FIXED Hotkeys interfering with the ship selection menu.
* ADDED an option to the Bot Options menu to send Self Bot output to SS.
* CHANGED RESET/PRETAX and UNLOCK now take place as soon as a SERVER RESET is announced.
* ADDED the ASSETS command to view a Corporate Situation Report.
* ADDED the MOTTO: entry to the z-options file for a corporate motto (shown on the ASSETS screen).
* CHANGED last command always sorted to top in HISTORY.
* CHANGED ALL HOTKEYS go off when not in general or command mode with the exception of Bot On/Off, Self Bot, and the Citadel Menu hotkeys.
* CHANGED - combined the CREEPER and CITMENU KEYS to the CITMENU KEY. The Default SHIP CAP KEY is now C. The P key is now spare. The CREEPERKEY is no longer used. - Remove the  CREEPERKEY:  entry from your z-options.cfg file.
* ADDED TURN MAXED OUT warnings every 15 minutes if HERALD TURNS is on and Z-Bot is not busy.
* ADDED the new Z-CommsGuard SCRIPT. This will take over responsibility from Z-Bot for keeping the comms alive. Also has the BOTNAME FINAL_PROTOCOL option over SS to KILL all scripts and reconnect.
* CHANGED SHIPS command without a range specified now just displays all ships (faster).
* CHANGED now using an edited version of CK BUYDOWN. z_ck_buydown is intended to stop the occasional hangup due to rounding errors between different versions of TWX.
* CHANGED if you use BUY to buy ore for speed and nothing else, OREUP will be used.
* ADDED a TIMEOUT (5 mins) to the Bot Options Menu.
* ADDED the internal SHIPSTATS system with gbonus-ships and automatic collection of alien ship stats. Remove the SHIPSTATS: entry from the z-options.cfg file.
* ADDED the SHIPCAP System. The CAP key and the movement system C option now utilise this. The old C option has been relocated to Z for Buzz. - REMOVE the  SHIPCAP: entry in your z-options.cfg file.
* ADDED CAP option to PDROP and PRELOCK.
* ADDED the CITCAP command.
* ADDED the CAP command to cap a ship in sector.
* FIXED the echoes in PDROP, CITKILL, EVAC, and CITCAP will not repeatedly display with the pulse.
* ADDED the H option to the movement system as a shortcut to the last fighit sector.
* CHANGED backed up files are now timestamped to avoid the need to delete backups.
* ADDED an alert to PDROP. The pdropalert.wav file will be played after the attack if the ALERT parameter is specified.
* ADDED a HOTKEY to set the MAIN PLANET. - add the following to the z-options.cfg file under KEY ASSIGNMENTS:   SETPLANETKEY: P
* ADDED z2_worldtrade.cts is an edited version of 2_worldtrade that has settings set and the menu bypassed making it bottable.
* CHANGED the motto entry to a config file with multiple mottos. Remove the MOTTO: entry from z-options.cfg if you have one. Z-Bot will create your z-mottos.cfg which you can edit.
* ADDED - The <Underground> prompt is now recognised by the movement system and many commands, allowing them to be run without previously changing prompts.

2.01
----
* ADDED the HOOKTOW key now puts you back on STARDOCK, ALPHA or RYLOS if thats where you started.
* ADDED the tilde [~] key now stops an ALIEN CAP. (Useful when they have too many shields and no fighters).
* FIXED SHIPSTATS endless loop if only 1 page of ships.
* ADDED the [X]-HOLOATTACK option to the MOVEMENT system (hotkeys and commands). This will continue an attack in an adjacent sector to the target sector if a target exists. (Using CAP unless the KILL option was used in the movement options)
* ADDED planet collisions to the NEWS.
* ADDED the ENEMYFIGS command to list sectors with enemy figs.
* ADDED the SHIPPRICES command to collect and display the ship prices.
* FIXED the SURROUND command and movement option now obey the fighter type set in the Bot Options Menu.
* ADDED the RETURN option to SPG to return to base after gridding.
* ADDED ship repossessions to NEWS.
* ADDED the RETIRE command to log out and shut down the z-bot in a citadel.
* FIXED the FURB refig option only giving 2 figs.
* ADDED to the Z-LOGIN script a LIFT AND CHARGE option to the TERRAKIT menu.
* FIXED using BUY F S will now withdraw cash if needed from citadel before running OREUP and will now return you to the Citadel if thats where you started.
* ADDED the PA command to photon a given adjacent sector.
* ADDED the XPORT command now responds to parameters N and L the same as P.
* ADDED a holoscan to the SURROUND command and the U movement option (updates the database before determining sectors to be figged).
* ADDED the SCRUB option to SPG.
* FIXED the PROMPT system now recognises when you are at the FedPolice prompt.
* FIXED the "no planets in sector" error when trying to LAND on another planet, from the Citadel prompt, immediately after logging in.
* ADDED the IgnoreScripts option to the Bot Options Menu. Z-Bot will ignore scripts loaded externally if TRUE.
* FIXED corpys can now have spaces in their name.
* CHANGED the TEAM command now displays the current team name when used without a parameter. Use the NONE parameter to clear the team.
* ADDED the SWITCHBOT command to unload Z-Bot and run another bot specified in z-options.cfg. Add the following to your z-options.cfg file.  SWITCHBOT: NONE
* ADDED CBYs to the NEWS.
* FIXED HERALDTURNS not correctly checking if busy.
* ADDED the XFER command to transfer figs/shields/mines to a corpy.
* ADDED EXTERNAL commands to the HELP ALL list.
* ADDED the ABOUT command to display the SPLASH screen.
* UNLOCKED the ability to launch ANY bot command with parameters as a movement option.
* CHANGED the HELP SORT algorithm to speed up sorts.
* CHANGED sped up the DP (density photon) scan.
* CHANGED the FURB command now sits on STARDOCK if the /dc option is used.
* ADDED the AUTOREFURB command to turn ON/OFF the AUTOREFURB (buy and deliver a furbship to a corpy automatically when they bust).
* ADDED the LAND command now displays available planets when a bad planet number is used.
* ADDED the SETFURB command to allow remote setting of the FURB SHIP and EXTRA HOLDS settings.
* CHANGED - rearranged some HELP lists.
* ADDED the ACTIVE command to display a list of active limps.
* ADDED the A thru Z parameters to the HELP command to display a list of ALL commands starting with the given letter.
* ADDED SEARCH functionality to the help system.
* ADDED the BS command to buy a ship and outfit it.
* ADDED the SP command to shield a planet using Twarp and Stardock.
* ADDED ability to add descriptions to external commands in the z-options.cfg. Place descriptions between square brackets after the script filename. (descriptions are searched)
* UNLOCKED PLOCK (renamed from prelock)
* ADDED the FCR command to turn ON/OFF the FEDCOM RESPONDER. See the z-fcr.cfg for info on setting up FCR.
* FIXED the SPG command not correctly recognising limped sectors <gulp!>
* FIXED SPG not heralding high density sectors when set to.
* FIXED ASSETS incorrect corp shield display.
* ADDED the ability to display any text file over SS or Fedcom from the BANNER hotkey.
* FIXED - speed improvement on ENEMYFIGS and COMPILE commands.
* ADDED courses to the NEAR commands display.
* FIXED the PROMPT system now recognises the "Mined Sector" prompt.
* ADDED the COURSE command to plot a safe course between 2 sectors and optionally attempt to move there.
* CHANGED SURROUND to check for shielded planets and too many figs rather than density.
* FIXED problem of the bot becoming unresponsive after running certain external scripts.
* CHANGED z2_WorldTrade is now more bottable (now has parameters) and has help for the parameters.
* CHANGED the SELLSHIPS command can now be started at the command prompt at stardock.
* CHANGED various DEFAULT Bot Menu settings to better reflect intended settings.
* ADDED a setting in the Bot Options menu to DISABLE the Movement System's TWARP Adjacent functionality (except when twarping to stardock).
* CHANGED in Z-PDRIVER the RIDER now deploys fighters and strips figs from planets. (rider needs fig capacity, driver needs the holds)
* FIXED the RECALL command not heralding it's completion.
* ADDED in Z-SECTORLISTER.CTS a numerical sort option to allow easier comparison of 2 lists.
* ADDED to Z-STRIP.CTS the F=xxx, O=xxx and E=xxx options to set the amount to take of each.

2.02
-----
RELEASE

2.10
-----
* ADDED SPG will now report ALIEN SPACE, over subspace, if found, and if SS= is set.
* ADDED the REFILL command now refills figs and shields from a class 0 or STARDOCK port if you are in those sectors.
* FIXED the MOVEMENT system stripping spaces from the [commandline].
* ADDED the MANIFEST command to display a list of ship data over subspace.
* CHANGED where the tilde key aborts, the BACKSPACE key will also abort, in most cases.
* ADDED to Z-PDRIVER a colonist trimmer.
* FIXED zWSST.cts hanging on the surrender prompt.
* FIXED SURROUND seeing phantom SHIELDED planets.
* ADDED the MACRO COMMAND LOOPER Hotkey. Add the line  LOOPKEY: M  to the KEY ASSIGNMENTS section of your z-options.cfg file.
* ADDED the Z-SWITCHBOT.CTS script to allow switching back to Z-Bot from another Bot.
* ADDED Z-Bot will send it's BOT NAME whenever it receives a corp memo.
* ADDED Z-Bot will occasionally announce your motto as a universal announcement upon startup. Add the following to your z-options.cfg: ANNOUNCEMOTTOS: ON
* ADDED the SS and FED parameters to the NEWS and ASSETS commands to redirect output.
* FIXED XPORT P option not scrubbing at stardock.
* ADDED the SECTOR command now displays if the sector is an MSL.
* FIXED error running PLOCK. Added the RETURN option and redirected output to SS.
* ADDED the WAVER command to wave on an adjacent sector and retreat.
* CHANGED the Z-COLONISER script will now place colonists in other slots if the chosen slot becomes full.
* ADDED the CONFIGURATOR Menu to the Bot Options Menu. This allows editing of main external config files.
* ADDED to the Z-PDRIVER script the option to save settings for AUTOMATE.
* FIXED Z-COLONISER hanging the Z-Bot and Not Turning comms back on when it exits prematurely.
* ADDED the EE command. A FAST enter/exit.
* ADDED the Z-Installer to optionally install the Z-Bot, The ZedPack, TWX Proxy (XP or Win7), and Putty. (with shortcuts)

2.11
-----
* FIXED RECONNECT routine crashing frequently.
* FIXED (hopefully) hangup waiting for subspace prompt some people were experiencing.
* ADDED the  TERRAKIT:ON  entry to the Z-Globals.cfg file to allow disabling of Terrakit. (just change it to off)
* ADDED the Z-Installer will now allow you to choose whether or not to configure putty, and will configure it during installation.

2.12
-----
Release

2.13
-----
* ADDED in Z-Login.cts a message to show if you joined/created a corp when you first start a game.
* FIXED Z-Installer not overwriting target files.

2.14
-----
Release

