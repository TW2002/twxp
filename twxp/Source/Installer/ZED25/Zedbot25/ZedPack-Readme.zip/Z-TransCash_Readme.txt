Title: Z-TransCash
Version: 1.06
Author: Zed
Contact: Archy at http://archysportal.com
Credits: Thanks to Parrothead.

Zed's Transfer Cash Script
---------------------------
Allows 2 players to exchange large amounts of cash through the Galactic Bank.
Switches to a user defind SS channel to do the transaction and switches back to the previous channel when done.
Saves the chosen temporary ss channel for future use as a default.
Choose whether to send or receive, how much to transfer, and who with from the menu.
A progress window will keep both players aware of where you are up to.
Enter a 0 on the menu for the subspace channel to use your existing subspace channel.
Start the script from the <Galactic Bank> prompt.

INSTALLATION
-------------
Place the readme, and the .wav file in your TWX root folder.
Place the script in your scripts folder.
