Title: Z-Armourer
Version: 1.13
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Armourer
--------------

A Bottable or standalone Class 0 Buydown script.

Takes your planet to a Class 0 port and fills it up with fighters and/or shields using your personal cash
and optionally the cash in your citadel.

You can choose whether to fill up fighters or shields or both.
You can also choose whether to use the citadel credits or not.

The script will leave your ship full of fighters and/or shields if it has the cash left after the buydown.
It will also return your planet to the sector where it started.

Start at the Citadel prompt.
Ensure that you have a fighter down at the class 0 you will use.
Ensure that you have enough cash for the buydown.

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the script in your scripts folder.
