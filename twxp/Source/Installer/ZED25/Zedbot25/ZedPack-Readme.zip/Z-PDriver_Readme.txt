Title: Z-PDriver
Version: 1.35
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Planet Driver
-------------------
Jumps a planet through a list of sectors. 
This allows you to do something in each sector (such as a buydown, upgrade, nego, etc...).
The list of sectors should be supplied by you and has a format of 1 sector per line. (use Z-SectorLister, Z-SectorLister's default output file is Z-Planets default input file.) 
What's on the line does not matter as long as the first "word" is the sector number.

Z-PDriver has 2 modes of operation:

MANUAL MODE
In the menu you can specify the filename of the sector list, and the keys used for proceeding, skipping a sector, Upgrading planets, upgrading a port, buying down, selling off product, returning to the starting sector, and exiting the script.
Z-PDriver will jump to each sector, waiting at each sector for a specified key to be pressed before moving on to the next. You can activate the buydown, nego and upgrade features at the press of a button while at each sector, or do most anything you like before proceeding to each sector in the list.

AUTOMATIC MODE
You can specify in the menu whether to upgrade the port in each sector, upgrade planets, buydown or nego, and what products to work with. You can also specify the buydown mode and whether or not to return to the starting sector when done.
The Turbo Buy Ore option is a fast alternative if you aren't worried about price when gassing up your planets.
Multi Nego allows you to visit sectors where you have product planets under buy ports and nego them all (until the port capacity is reached). The menu allows you to set "Sell full first" mode which will nego the planet which is fullest. (Hopefully avoiding having full planets and allowing production to continue.)
Planet Stripper will collect ore, organics, equipment and fighters from all planets in each sector.

Once you press the GO key it should whip through all the sectors in the list doing the specified actions automatically.

You can Set the script to stop when you have sold all the stock you are selling, or when you are full of the stock you are buying. or both. You can also set it to stop when you are simply sold out of Equipment.
You can set the starting point from within the sector list you are working with, allowing you to continue from a point you stopped at previously. (get the sector number to go back to from the Info window before you quit).

The sector list filenames offered by default can be edited in a file called z-sectorlist.cfg located in the TWX Root. Z-PDriver uses the OUTPUT filenames in this list.


Start the script from the CITADEL prompt.

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the scripts (including the buydown and nego scripts) in your scripts folder.

Note: This script uses Cherokee's Buydown and Nego Scripts to do the actual buying and selling.
Credit to Cherokee for his great work on these timeless scripts. Thanks for making them available to us.
Also this script makes use of an edited version of the MassUpgrade Script from the TWX Pack 2 scripts.
