Title: Z-Strip
Version: 1.03
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Planet Stripper
----------------------
Strips a specified planet of fuel ore, organics, equipment, fighters and colonists and moves them to the planet you ran the script from.

The stripping order is as follows. Colonists, equipment, fuel ore , organics, fighters.

Z-Strip will stop before you run out of turns in a turn game.

This script is bottable.. use the help or ? parameter for a list of parameters.
Start this script from the PLANET prompt of the planet you wish to fill.

If botted without parameters it will go into menu mode as if run standalone. Therefore it will timeout and exit if no key is pressed at the menu within 30 seconds.

COLO MACRO mode means moving the colonists using a macro burst.. making it much faster. But there are no checks so you must make sure there is enough room in each slot on the fill planet for the colos from the corresponding slots of the strip planet.

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the script in your scripts folder.
