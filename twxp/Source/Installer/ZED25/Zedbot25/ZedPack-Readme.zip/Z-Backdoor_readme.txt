Title: Z-Backdoor
Version: 1.06
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Backdoor Finder
---------------------

Find all the backdoors for Terra, Stardock, Rylos, Alpha, and a sector of your choice.
Saves the info in the Game Database CFG file.
Send the info to your Corpys via Sub Space.
Does not need a ZTM.
Will feed Z-Menu with backdoor info for the Macro Variables.