Title: Z-Rescue
Version: 1.09
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Rescue Service
---------------------
A Saveme script.
Allows you to set the delay before returning after a failed pickup.
Also allows you to set whether or not to return after a successful pickup.

This script is bottable.
Use BOTNAME zrescue ?  or BOTNAME zrescue help for details.

If using with Mombot you should copy the script to the appopriate Mombot script folder and rename it to zrescue (no minus sign).

Start this script from the Citadel Prompt.

INSTALLATION
-------------
Place the script in your scripts folder.
Place the .wav files in your TWX Root.
