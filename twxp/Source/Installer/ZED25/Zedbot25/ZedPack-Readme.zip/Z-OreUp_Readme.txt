Title: Z-OreUp
Version: 1.06
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Ore Up
-------------
Buys down ore (fast) from a port in sector to the planet you are on when you run it.
No Menu.. No Parameters.. 

Run this script from the PLANET prompt.

Can be botted.

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the script in your scripts folder.
