Title: Z-SafetyNet
Version: 1.09
Author: Zed
Contact: Archy at http://archysportal.com

Zed's Safety Net
-----------------
Sits in the background and reacts to an attack by attempting to xport to your safeship. If That fails it will do a call saveme. All non-system scripts will be terminated immediately upon export.
You can set the safeship ID number and tell the script to test it at the menu.
You will be exported to and from the safeship to ensure it is available. While it is there it will set the safeship to personal.
This script will make entries in the GAMENAME_Z-Logs.log file in your TWX Root.

Press [CTRL-N] to return to the menu.

Run this script from the COMMAND prompt.

Note that when you run this script and/or test the safeship it will attempt to place you at the command prompt.

INSTALLATION
-------------
Place the readme, and the .wav files in your TWX root folder.
Place the script in your scripts folder.
